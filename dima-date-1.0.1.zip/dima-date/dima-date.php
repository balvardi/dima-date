<?php
/*
Plugin Name: Dima Date - تاریخ شمسی (PHP 8+)
Plugin URI:  https://example.com/dima-date 
Description: تبدیل تمام تاریخ‌ها در وردپرس به شمسی با قابلیت تنظیم در ادمین.
Version:     2.0
Author:      دیما
Author URI:  https://example.com 
License:     GPL2
Text Domain: dima-date
Domain Path: /languages
*/

if (!defined('ABSPATH')) {
    exit;
}

// Define paths
define('DIMA_DATE_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('DIMA_DATE_PLUGIN_URL', plugin_dir_url(__FILE__));

// Load dependencies
require_once DIMA_DATE_PLUGIN_DIR . 'vendor/jdf.php';

// Admin settings
if (is_admin()) {
    require_once DIMA_DATE_PLUGIN_DIR . 'admin/settings.php';
    new Dima_Date_Settings();
}

// Load options
$dima_date_format = get_option('dima_date_format', 'l، j F Y');

// Convert date using format
function dima_convert_to_jalali(string|int|float|null $the_date, string $format = '', int|string|null $timestamp = null): string {
    global $dima_date_format;

    if (!$timestamp && is_string($the_date)) {
        $timestamp = strtotime($the_date);
    }

    if (!$timestamp) {
        return __('نامشخص', 'dima-date');
    }

    $jalali_format = !empty($format) ? $format : $dima_date_format;

    return jdate($jalali_format, $timestamp);
}

// Apply filters
add_filter('get_the_date', 'dima_convert_to_jalali', 10, 4);
add_filter('get_the_time', 'dima_convert_to_jalali', 10, 4);
add_filter('the_date', 'dima_convert_to_jalali', 10, 4);
add_filter('get_comment_date', 'dima_convert_to_jalali', 10, 3);
add_filter('post_modified_date_column', 'dima_convert_to_jalali', 10, 4);
add_filter('post_date_column', 'dima_convert_to_jalali', 10, 4);
add_filter('the_modified_date', 'dima_convert_to_jalali', 10, 3);

// REST API Support
add_filter('rest_prepare_post', function ($response, $post, $request) {
    $data = $response->get_data();

    $data['date'] = jdate(get_option('dima_date_format', 'Y/m/d'), strtotime($data['date']));
    $data['modified'] = jdate(get_option('dima_date_format', 'Y/m/d'), strtotime($data['modified']));

    $response->set_data($data);
    return $response;
}, 10, 3);