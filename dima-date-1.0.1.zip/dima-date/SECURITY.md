# Security Policy

## Reporting a Vulnerability

If you discover a security vulnerability within **Dima Date**, please send an email to the maintainer at [your-email@example.com](mailto:your-email@example.com) instead of creating a public issue on GitHub.

All security reports will be reviewed promptly and addressed as soon as possible.

For general issues or feature requests, feel free to open an issue on GitHub.