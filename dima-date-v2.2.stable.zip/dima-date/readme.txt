=== Dima Date - Persian (Jalali) Date Plugin ===
Contributors: balvardi
Tags: persian date, jalali calendar, shamsi date, wordpress date, iranian date
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.0.0-beta
License: GNU General Public License v2.0 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html 

Convert all dates in WordPress to Jalali (Shamsi) calendar with full admin settings and PHP 8+ support.

== Description ==

Dima Date is a modern WordPress plugin that converts all visible dates (posts, comments, edit screens, REST API responses) into the Jalali (Persian/Shamsi) calendar.

✅ Fully customizable date format  
✅ Admin settings page  
✅ REST API support  
✅ No server-side dependencies  
✅ Built with PHP 8+ features  

Perfect for Iranian websites looking to display dates in the Jalali calendar without relying on server configurations.

== Installation ==

1. Go to **Plugins > Add New**.
2. Search for "Dima Date".
3. Click **Install Now**, then **Activate**.

Or manually:
1. Download the plugin `.zip` file.
2. Go to **Plugins > Add New > Upload Plugin**.
3. Upload and activate the plugin.

== Frequently Asked Questions ==

= Does it work without jdate() PHP extension? =

Yes! This plugin uses an internal Jalali conversion library, so no need for any extra PHP extensions.

= Can I change the date format? =

Yes! Go to **Settings > تاریخ شمسی** and enter your preferred format like `Y/m/d` or `l، j F Y`.

= Is REST API supported? =

Yes! Dates returned by `/wp-json/wp/v2/posts` will be shown in Jalali format.

== Changelog ==

= 1.0.0-beta =
* Initial beta release