<?php

class Dima_Date_Settings {

    public function __construct() {
        add_action('admin_menu', [$this, 'add_plugin_page']);
        add_action('admin_init', [$this, 'page_init']);
    }

    public function add_plugin_page() {
        add_options_page(
            'تنظیمات تاریخ شمسی',
            'تاریخ شمسی',
            'manage_options',
            'dima-date-admin',
            [$this, 'create_admin_page']
        );
    }

    public function create_admin_page() {
        ?>
        <div class="wrap">
            <h1>تنظیمات تاریخ شمسی</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('dima_date_group');
                do_settings_sections('dima-date-admin');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function page_init() {
        register_setting(
            'dima_date_group',
            'dima_date_format',
            ['sanitize_callback' => 'sanitize_text_field']
        );

        add_settings_section(
            'dima_date_section',
            'قالب تاریخ شمسی',
            function () {
                echo '<p>قالب پیش‌فرض تاریخ شمسی را مشخص کنید:</p>';
            },
            'dima-date-admin'
        );

        add_settings_field(
            'dima_date_format',
            'قالب تاریخ',
            function () {
                $value = get_option('dima_date_format', 'l، j F Y');
                echo '<input type="text" name="dima_date_format" value="' . esc_attr($value) . '" class="regular-text">';
                echo '<p class="description">مثال: <code>Y/m/d</code> → 1402/10/05 | <code>l، j F Y H:i</code> → دوشنبه، 5 دی 1402 13:45</p>';
            },
            'dima-date-admin',
            'dima_date_section'
        );
    }
}